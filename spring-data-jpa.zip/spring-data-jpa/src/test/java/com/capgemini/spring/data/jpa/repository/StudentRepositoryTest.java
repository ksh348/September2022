package com.capgemini.spring.data.jpa.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.spring.data.jpa.entity.Guardian;
import com.capgemini.spring.data.jpa.entity.Student;

@SpringBootTest // Change DB
//@DataJpaTest // no change in DB
class StudentRepositoryTest {

//	@Autowired
//	StudentRepository repository;

//	@Test
	public void saveStudentTest() {
	
//		Student student = Student.builder()
//				.emailId("student@cg.com")
//				.firstName("first")
//				.lastName("last")
//				.guardian(Guardian.builder()
//						.gurdianName("guard")
//						.gurdianEmail("guard@gmail.com")
//						.gurdianMobile("1234567890")
//						.build())
//				.build();
//		repository.save(student);
	}
	
//	@Test
	public void getStudentsByFitstNameTest() {
	
//		List<Student> listStudents =  repository.findByFirstName("first");
//		System.out.println(listStudents);
	}

//	@Test
	public void getStudentsByFitstNameContainingTest() {
	
//		List<Student> listStudents =  repository.findByFirstNameContaining("first");
//		System.out.println(listStudents);
	}

}
