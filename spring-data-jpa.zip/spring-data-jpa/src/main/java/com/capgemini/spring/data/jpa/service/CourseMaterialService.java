package com.capgemini.spring.data.jpa.service;

import java.util.List;
import java.util.Optional;

import com.capgemini.spring.data.jpa.entity.CourseMaterial;

public interface CourseMaterialService {
	CourseMaterial create(CourseMaterial material);
	CourseMaterial update(CourseMaterial material);
	Optional<CourseMaterial> read(Long courseId);
	void delete(Long materialId);
	void delete(CourseMaterial material);
	
	List<CourseMaterial> findAll();
	
}