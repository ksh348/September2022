package com.capgemini.spring.data.jpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.spring.data.jpa.entity.Student;
import com.capgemini.spring.data.jpa.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository repository;
	
	@Override
	public List<Student> findAll() {
		
		return repository.findAll();
	}

	@Override
	public Student save(Student student) {
		// TODO Auto-generated method stub
		return repository.save(student);
	}

	@Override
	public Optional<Student> findById(Long studentId) {
		// TODO Auto-generated method stub
		return repository.findById(studentId);
	}

}