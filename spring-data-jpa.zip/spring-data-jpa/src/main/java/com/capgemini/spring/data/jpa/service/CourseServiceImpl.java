package com.capgemini.spring.data.jpa.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.spring.data.jpa.entity.Course;
import com.capgemini.spring.data.jpa.repository.CourseRepository;

public class CourseServiceImpl implements CourseService {

	@Autowired
	CourseRepository repository;
	
	@Override
	@Transactional
	public Course create(Course course) {
		return repository.save(course);
	}

	@Override
	@Transactional
	public Course update(Course course) {
		Course exists = null;
		if(repository.existsById(course.getCourseId()))
			exists= repository.save(course);
		return exists;
	}

	@Override
	public Course read(Long courseId) {
		
		return repository.findById(courseId).get();
	}

	@Transactional
	@Override
	public void delete(Long courseId) {
		repository.deleteById(courseId);
	}

	@Transactional
	@Override
	public void delete(Course course) {
		repository.delete(course);
	}
}
