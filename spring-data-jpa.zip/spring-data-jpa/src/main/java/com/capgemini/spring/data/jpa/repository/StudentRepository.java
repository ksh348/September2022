package com.capgemini.spring.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.spring.data.jpa.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{
//	List<Student> findByFirstName(String firstName);
//	
//	List<Student> findByFirstNameNotNull();
//	
//	List<Student> findByFirstNameContaining(String firstName);
//	
//	List<Student> findByGuardianGurdianName(String gurdianName);
//	
//	//JPQL
//	@Query("Select s from Student where s.gurdianEmail = ?1")
//	List<Student> getByJpqlQuery(String email);
//	
//	//Native
//	@Query(
//			value = "Select * from Student s where s.gurdianEmail = ?1",
//			nativeQuery = true)
//	List<Student> getByNativeQuery(String email);
//	
//	//NativeNamed
//	@Query(
//				value = "Select * from Student s where s.gurdianEmail = :emailId",
//				nativeQuery = true)
//		List<Student> getByNativeQueryNamed(@Param("emailId") String email);
}
