package com.capgemini.spring.data.jpa.exception;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExceptionDescription {
	private int errorCode;
	private String message;
	private String description;
	
}
