package com.capgemini.spring.data.jpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.spring.data.jpa.entity.CourseMaterial;
import com.capgemini.spring.data.jpa.repository.CourseMaterialRepository;

@Service
public class CourseMaterialServiceImpl implements CourseMaterialService {

	@Autowired
	CourseMaterialRepository repository;
	
	@Override
	public CourseMaterial create(CourseMaterial material) {
		
		return repository.save(material);
	}

	@Override
	public CourseMaterial update(CourseMaterial material) {
		CourseMaterial updated = null;
		if(repository.existsById(material.getMaterialId()))
			updated = repository.save(material);
		
		return updated;
	}

	@Override
	public Optional<CourseMaterial> read(Long materialId) {
		
		return repository.findById(materialId);
	}

	@Override
	public void delete(Long materialId) {
		repository.deleteById(materialId);
	}

	@Override
	public void delete(CourseMaterial material) {
		repository.delete(material);
	}

	@Override
	public List<CourseMaterial> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	
	

}
