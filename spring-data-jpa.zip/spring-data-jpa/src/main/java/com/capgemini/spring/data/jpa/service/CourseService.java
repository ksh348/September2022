package com.capgemini.spring.data.jpa.service;

import com.capgemini.spring.data.jpa.entity.Course;

public interface CourseService {
	Course create(Course course);
	Course update(Course course);
	Course read(Long courseId);
	void delete(Long courseId);
	void delete(Course course);
}
