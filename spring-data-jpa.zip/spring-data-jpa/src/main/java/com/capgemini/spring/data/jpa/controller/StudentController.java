package com.capgemini.spring.data.jpa.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.spring.data.jpa.entity.Student;
import com.capgemini.spring.data.jpa.exception.MyOwnException;
import com.capgemini.spring.data.jpa.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService service;
	
	@PutMapping("/save") //, produces = "application/json", consumes = "application/json", method = RequestMethod.POST)
	public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
		
		Student saved = null;
		
		 saved = service.save(student);
		
//		 System.err.println(saved);
		return new ResponseEntity<Student>(saved, HttpStatus.OK);
	}
	
	@GetMapping("/get/{studentId}")
	public Student getStudentById(@PathVariable Long studentId) {
		Student student = service.findById(studentId).orElseThrow(()-> new MyOwnException("Student does not found"));
		return student;
	}
	
	@GetMapping("/get/all")
	public ResponseEntity<List<Student>> getAll() {
		List<Student> studentList = service.findAll();
		return new ResponseEntity<List<Student>>(studentList , HttpStatus.OK);
	}
}
