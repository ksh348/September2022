package com.capgemini.spring.data.jpa.exception;

public class MyOwnException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public MyOwnException(String message) {
		super(message);
	}
}
