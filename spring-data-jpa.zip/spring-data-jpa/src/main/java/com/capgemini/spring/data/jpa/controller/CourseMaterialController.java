package com.capgemini.spring.data.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.spring.data.jpa.entity.CourseMaterial;
import com.capgemini.spring.data.jpa.exception.MyOwnException;
import com.capgemini.spring.data.jpa.service.CourseMaterialService;

@Controller
@RequestMapping("/material")
public class CourseMaterialController {

	@Autowired
	private CourseMaterialService service;
	
	@PutMapping("/save") //, produces = "application/json", consumes = "application/json", method = RequestMethod.POST)
	public ResponseEntity<CourseMaterial> saveStudent(@RequestBody CourseMaterial material) {
		
		CourseMaterial saved = null;
		
		 saved = service.create(material);
		
//		 System.err.println(saved);
		return new ResponseEntity<CourseMaterial>(saved, HttpStatus.OK);
	}
	
	@GetMapping("/get/{materialId}")
	public ResponseEntity<CourseMaterial> getStudentById(@PathVariable Long materialId) {
		CourseMaterial matetail = service.read(materialId).orElseThrow(()-> new MyOwnException("Student does not found"));
		return new ResponseEntity<CourseMaterial>(matetail, HttpStatus.OK);
	}
	
	@GetMapping("/get/all")
	public ResponseEntity<List<CourseMaterial>> getAll() {
		List<CourseMaterial> materialList = service.findAll();
		return new ResponseEntity<List<CourseMaterial>>(materialList , HttpStatus.OK);
	}
}
