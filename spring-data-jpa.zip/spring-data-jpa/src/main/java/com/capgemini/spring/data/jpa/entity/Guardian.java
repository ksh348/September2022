package com.capgemini.spring.data.jpa.entity;

import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Embeddable
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Guardian {
	private String gurdianName;
	private String gurdianEmail;
	private String gurdianMobile;
}
