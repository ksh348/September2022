package com.capgemini.spring.data.jpa.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice 
public class ExceptionHandler {

	@org.springframework.web.bind.annotation.ExceptionHandler(MyOwnException.class)
	public ResponseEntity<?> handleMyOwnException(MyOwnException myException, WebRequest request){
		ExceptionDescription descript = new ExceptionDescription(666, myException.getMessage(), request.getDescription(false));
		return new ResponseEntity(descript, HttpStatus.BAD_REQUEST);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleAnyException(Exception exception, WebRequest request){
		ExceptionDescription descript = new ExceptionDescription(666, exception.getMessage(), request.getDescription(false));
		return new ResponseEntity(descript, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
