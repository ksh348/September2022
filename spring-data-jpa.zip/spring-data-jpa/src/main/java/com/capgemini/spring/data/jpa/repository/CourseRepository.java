package com.capgemini.spring.data.jpa.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.spring.data.jpa.entity.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long>{
//	//Jpql
//	@Query(value = "select c from Course")
//	List<Course> getAllCoursesByJPQLQuery();
//	
//	@Query(value = "SELECT * from tbl_course", nativeQuery = true)
//	List<Course> getAllCoursesBySQLQuery();
//	
//	Course findByTitle(String title);
	
}
